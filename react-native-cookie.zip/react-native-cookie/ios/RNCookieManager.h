
#import "RCTBridgeModule.h"

@interface RNCookieManager : NSObject <RCTBridgeModule>
@end
