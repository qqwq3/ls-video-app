import Cookie from './cookie';
export default Cookie;
