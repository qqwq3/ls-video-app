import { AppRegistry } from 'react-native';
// import App from './App';
import AppBackup from './AppBackup';

AppRegistry.registerComponent('agoutv', () => AppBackup);
