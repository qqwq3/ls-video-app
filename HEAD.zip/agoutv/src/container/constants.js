import { StyleSheet } from 'react-native';
export const TabIconStyle = StyleSheet.create({
    tabIcon: {
        width: 25,
        height: 25,
    }
})

export const numPerPage = 20;