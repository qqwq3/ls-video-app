
'use strict';

import type {Action} from "../actions/types";
import { RefreshState } from "../Constants";
import Immutable from 'immutable';

// 设置初始值
const initialState = Immutable.fromJS({});

// 执行处理
const foundIndex = (state = initialState, action: Action) => {

};

module.extends = foundIndex;









































